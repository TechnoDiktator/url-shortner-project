package com.ulr.shortner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlShortnerSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
